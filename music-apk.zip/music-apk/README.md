# Музыка: сборка APK

## Способ 1 (без установки программ): GitHub Actions
1. Создайте репозиторий на github.com и загрузите в него ВСЕ файлы этой папки с сохранением структуры
   (в том числе `.github/workflows/build.yml`, `www/index.html`). Удобнее с компьютера или в режиме «Версия для ПК».
2. Откройте вкладку **Actions** → **Build APK** → **Run workflow** (сборка занимает 5–8 минут).
3. Откройте завершённый запуск → внизу **Artifacts** → скачайте `muzyka-apk`, распакуйте.
4. Установите `app-debug.apk` на телефон (разрешите установку из неизвестных источников).

## Способ 2 (локально)
```
npm install
npx cap add android
npx cap sync android
npx cap open android   # Android Studio → Build → Build APK(s)
```

Страница лежит в `www/index.html`. После правок выполните `npx cap sync android`.
